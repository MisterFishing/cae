<?php
	echo "<h1 style='text-align: center;'>Hello PHP</h1><p style='text-align: center;'>Welcom to Cloud APP World!</p>";
?>
